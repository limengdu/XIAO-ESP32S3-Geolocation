#if defined (ESP32) || defined (ARDUINO_ARCH_ESP8266) || defined (ARDUINO_ARCH_RP2040)
  #define TJPGD_LOAD_FFS
#endif

#define TJPGD_LOAD_SD_LIBRARY
